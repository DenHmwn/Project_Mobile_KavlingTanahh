class Property {
  final String id;
  final String name;
  final String type;
  final String location;
  final String imageAsset;
  final double rating;
  final List<String> availableSlots;

  Property({
    required this.id,
    required this.name,
    required this.type,
    required this.location,
    required this.imageAsset,
    required this.rating,
    required this.availableSlots,
  });

  static List<Property> getDummyData() {
    return [
      Property(
        id: '1',
        name: 'Type 36',
        type: 'Deep Foam',
        location: 'Kelapa 7',
        imageAsset: 'assets/images/house1.jpg',
        rating: 4.8,
        availableSlots: ['09:00 - 10:30', '11:00 - 12:30', '13:00 - 14:30'],
      ),
      Property(
        id: '2',
        name: 'Type 67',
        type: 'Espresso',
        location: 'Sepakat 4',
        imageAsset: 'assets/images/house2.jpg',
        rating: 4.8,
        availableSlots: ['09:00 - 10:30', '11:00 - 12:30', '13:00 - 14:30'],
      ),
      Property(
        id: '3',
        name: 'Kavling 7',
        type: 'Kali Balangan',
        location: 'Kali Balangan',
        imageAsset: 'assets/images/field.jpg',
        rating: 4.8,
        availableSlots: ['09:00 - 10:30', '11:00 - 12:30', '13:00 - 14:30'],
      ),
      Property(
        id: '4',
        name: 'Kavling 17',
        type: 'Kota Alam',
        location: 'Kota Alam',
        imageAsset: 'assets/images/field.jpg',
        rating: 4.8,
        availableSlots: ['09:00 - 10:30', '11:00 - 12:30', '13:00 - 14:30'],
      ),
    ];
  }
}
